<?php

set_include_path ( ".:/var/www/vailhex/" );

include_once 'phpLibraries/UI/Page/Page.php';

/**
 *
 * @author Joel Villasuso for VailHex
 *
 */
abstract class ShellData{ 

	abstract public function genShellContent();

	abstract public function genShellButtons();
	abstract public function genShellMenu();
	abstract public function genShellDetails();
	
	final public function genShell(){
		$o = "";
	
		if ($this->genShellButtons())
			$o .= "<div class='buttonSet'>".$this->genShellButtons()."</div>";
	
		if ($this->genShellDetails())
			$o .= "<div class='securedetails' id='secDetLeft'>".$this->genShellDetails()."</div>";

		if ($this->genShellMenu())
			$o .= "<div class='securedetails' id='secDetRight'>".$this->genShellMenu()."</div>";

		if ($this->genShellContent())
			$o .= "<div class='secureContent'>".$this->genShellContent()."</div>";

			return $o;
	}

}