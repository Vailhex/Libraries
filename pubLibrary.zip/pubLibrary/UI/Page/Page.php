<?php

set_include_path ( ".:/var/www/vailhex/" );

include_once 'phpLibraries/formCreator.php';
include_once 'phpLibraries/managers/errorManager.php';
include_once 'phpLibraries/managers/dataSecurity.php';

foreach (glob("phpLayout/pages/*.php") as $filename)
{
	include_once $filename;
}

/**
 * A cookie-cutter template for any Page.
 * Base for the subsequential children pages.
 * Defines the basic methods for Page display, UI, and security. 
 *
 * @author Joel Villasuso for VailHex
 *
 */
abstract class Page {

	/* IDEA create a ProtectedPage child class to generate alternative info
	 *  -> page would show different pieces of content whether someone was logged or not
	 *  -> could also be attempted through a method used in PublicPage.
	 */

	/* IDEA Create a system that allows different subPages
	 *  -> ex: page?one != page?two
	 *  -> problem with the way pages are called and stored for display.
	 */
	
	private $subUrl;
	
	function __construct($subUrl = "") {
		$this->subUrl = $subUrl;
	}
	
	function getLink() {
		return $this->subUrl;
	}
	
	/**
	 * Allows for the definition of a Metadata structure.
	 * Metadata is included whithin the HTML header tag.
	 *  
	 * @return string
	 */
	abstract public function getMeta();
	
	/**
	 * Allows for the definition of a Header structure.
	 * Header is the first part of the HTML body tag.
	 * 
	 * @return string
	 */
	abstract public function getHeader();
	
	/**
	 * Allows for the definition of a Body structure.
	 * Body is defined after Header in the HTML body tag.
	 * Not to be confused with the body tag itself, 
	 * but meant to be the content of the page
	 * 
	 * @return string
	 */
	abstract public function getBody();
	
	/**
	 * Allows for the definition of a Footer structure.
	 * Footer is last defined within the HTML body tag.
	 * 
	 * @return string
	 */
	abstract public function getFooter();
	
	
	/**
	 * Allows for the definition of a non-standard doctype.
	 * 
	 * @return string
	 */
	abstract public function getDoctype();
	
	
	//TODO getHTMLProperties possibly redefined better in Public or Secure.
	/**
	 * Allows for the definition of a HTML properties like style or class. 
	 * 
	 * @return string
	 */
	abstract public function getHTMLProperties();
	
	//TODO getBodyProperties probably redefined better in Public or Secure 
	/**
	 * Allows for the definition of the body properties like style or class.
	 * 
	 * @return string
	 */
	abstract public function getBodyProperties();
	
	
	/**
	 * Returns the name of the calling class.
	 * Any child class will output it's class, rather than 
	 * that of the original ancestor (Page), hence dynamic.
	 * This function is used to find out what page you are on, through no 
	 * hierarchy capacities is provided.
	 * 
	 * @return string
	 */
	public function getName(){
		return get_called_class();
	}
	/**
	 * Finds out whether the user is logged in or not.
	 * Based on DataSecurity for login information
	 * 
	 * @return boolean
	 */
	public function isLogged() {
		if ( $s = DataSecurity::get_from_session ()) {
			return $s->isVerified ();
		} else
			return false;
	}
	
	public function alternateContent( $public = "", $private = ""){
		if (self::isLogged()){
			return $private;
		}else{
			return $public;
		}
	}
	
	/**
	 * Generates the page itself.
	 * It goes through a number of security checks regarding
	 * login or the content of secure/private information.
	 * Supported through the usage of private and public generate.
	 * 
	 * @return string
	 */
	public function generate( $secure = false){
		if($secure == false ){
			return $this->publicGenerate();
		}else{
// 			$this->identifyLogout(); //verifies if logout
// 			$this->identifyLogin(); //verifies incoming data if any.
// 			$this->identifyRegister(); //verifies incoming data if any.
			/* migrated to DataSecurity and identifySecureAction*/
			
			$this->identifySecureAction();
			
			if ($this->isLogged()){
				return $this->publicGenerate();
				
			}else{
				return $this->privateGenerate();
			}
		}
	}
	
	/**
	 * Echoes the content of the page directly into the screen.
	 * The body tag is only filled by privateVerification, whose 
	 * output changes depending on the data provided.
	 */
	private function privateGenerate(){
		echo $this->getDoctype();
		echo "<html style=\"".$this->getHTMLProperties()."\">
				<head>
					".$this->getMeta()."
				</head>
				<body style=\"".$this->getBodyProperties()."\">
					".$this->privateVerification()."
				</body>
			</html>";
	}
	
	
	/**
	 *  Simply outputs the data defined previously.
	 */
	private function publicGenerate(){
		echo $this->getDoctype();
		echo "<html style=\"".$this->getHTMLProperties()."\">
				<head>
					".$this->getMeta()."
				</head>
				<body style=\"".$this->getBodyProperties()."\">
					".$this->getHeader()."
					".$this->getBody()."
					".$this->getFooter()."
				</body>
			</html>";
	}
	
	/**
	 * Gets the parameters for login and verifies them.
	 * Output quantifies the data accordingly.
	 * 
	 * @return boolean|NULL
	 */
	private static function identifySecureAction(){
		if(isset($_GET['logout'])){
			DataSecurity::logout();
		}elseif(isset($_GET['register'])){
			DataSecurity::register();
		}else{//if(isset($_GET['login'])){
			DataSecurity::login();
		}
// 		else{
// 			echo "identify secure action error!!!";
// 		}
	}
	
	/**
	 * Decides whether to generate Login, Register, or Logout.
	 * This is decided depending on whether GET has 'logout', 'register' 
	 * or (default) 'login'.
	 * 
	 * @return string
	 */
	final public function privateVerification(){
		if(isset($_GET['logout'])){ //logout query
			return $this->generateLogout();
			
		}elseif (isset($_GET['register'])){ //registration query
			return $this->generateRegisterForm();
		
		}else{ //if(isset($_GET['login'])){ //login query >> DEFAULT
			return $this->generateLoginForm();
		}
		
	}
	
	
	/**
	 * Generates a rough login page.
	 * Any previous login username will be outputed if still in memory.
	 * Utilizes FormFactory to generate the Login Form.
	 * 
	 * @return string HTML login form
	 */
	public function generateLoginForm() {

		$usr = (isset($_POST['login_username']))?
			ease::postIsset('login_username')
			:"";
// 			:DataSecurity::get_from_session()->get_username_insecurely() ;
		
		$form = new FormFactory ();
		$form->setHeader ( null, true, 'login Form', new urlParam ( 'login', " " )  );
		$form->addInput ( new inputText("form_header", "Login"));
		$form->addInput ( new inputField ( 'login_username', 'Username', 'text', true, $usr ) );
		$form->addInput ( new inputField ( 'login_password', 'Password', 'password', true ) );
		/*ERROR*/		$form->addInput ( errorManager::getError('query_retrieveProfile_error')->genInputError() );
		$form->setSubmit ( "Login", "loginSubmit" );
		$form->addInput ( new LineBreak () );
		$form->addExtra ( new inputText ( "register_option", "Not a user yet? >> <a href='".$this->getName()."?register'>REGISTER</a>" ) );
		$form->addExtra ( new inputText ( "register_option id=logHome", "Go home >> <a href='/'>HOME</a>" ) );
		
		return $form->__toString ();
	}
	
	/**
	 * Generates a rough, hardwired registration form.
	 * Any data sent previously will be returned as the default 
	 * for the field if the registration request fails.
	 * 
	 * @return string HTML registration form
	 */
	public function generateRegisterForm() {
		//TESTME changed getIsset() usage throughout the Form
		//PENDING error returning

// 		$o = "<h1>Registration</h1>";
		
		$hint = "<b>Must include:</b><ul>
				<li>10 to 16 characters</li>
				<li>An uppercase letter</li>
				<li>A lowecase letter</li>
				<li>A number</li>
				</ul>";
	
		$form = new FormFactory ();
	
		$form->setHeader ( null, true, 'register Form', new urlParam (  'register', " "  ) )
		
// 		registration_username
// 		registration_password1
// 		registration_password2
// 		registration_email
		
// 		registration_phone
// 		registration_first_name
// 		registration_last_name
// 		registration_company

		->addInput ( new inputText("form_header", "Registration"))
// 		->addInput ( new inputField ( "registration_email", "Email", "email", true, ease::postIsset ( 'registration_email' ) ) )
// 		/*ERROR*/	->addInput ( errorManager::getError('prot_emailProtocol_error')->genInputError() )
		->addInput ( new inputField ( "registration_username", "Username", "text", true, ease::postIsset( 'registration_username' ) ) )
		/*ERROR*/	->addInput ( errorManager::getError('prot_usrProtocol_error')->genInputError() )
		/*ERROR*/	->addInput ( errorManager::getError('query_checkUsername_error')->genInputError() )
		->addInput ( new inputField ( "registration_password1", "Password", "password", true ) )
// 		->addInput ( new inputText ( "hint", $hint ) )
		->addInput ( new inputField ( "registration_password2", "Repeat password", "password", true ) )
		/*ERROR*/	->addInput ( errorManager::getError('passMismatch')->genInputError() )
		/*ERROR*/	->addInput ( errorManager::getError('passProtocol')->genInputError() )
// 		->addInput ( new LineBreak () )
// 		->addInput ( new inputField ( "registration_first_name", "First name", "text", false, ease::postIsset ( 'registration_first_name' ) ) )
// 		->addInput ( new inputField ( "registration_last_name", "Last name", "text", false, ease::postIsset ( 'registration_last_name' ) ) )
// 		->addInput ( new inputField ( "registration_company", "Company name", "text", false, ease::postIsset ( 'registration_company' ) ) )
// 		->addInput ( new inputField ( "registration_phone", "Phone number", "text", false, ease::postIsset ( 'registration_phone' ) ) )

		->addInput ( new LineBreak () )
		->setSubmit ( "Register", 'registerSubmit' )
		->addExtra ( new inputText ( "register_option", "Already a user? >> <a href='".$this->getName()."?login'>LOGIN</a>" ) )
		->addExtra ( new inputText ( "register_option", "Go home >> <a href=''>HOME</a>" ) );
	
		return $form->__toString ();
	}
	
	/**
	 * Generates a logout message for a successful logout.
	 * Used similarly to loginForm and registerForm, and replaces them in page when called.
	 * Currently has issues with retrieving data since it displayed only after logout and data is 
	 * no longer available for display/reading.
	 * 
	 * @return string Logout page
	 */
	public function generateLogout(){
		$o = "<h1>Logout</h1>";
		$o .= "<h2>Thank you for using our services</h2>";
		$o .= "<a href='/dash'>Login</a></br>";
		$o .= "<a href='/'>Home</a>";
		
		return $o;
	}
}