<?php
set_include_path ( ".:/var/www/vailhex/" );

include_once 'phpLibraries/formCreator.php';
include_once 'phpLibraries/managers/errorManager.php';
include_once 'phpLibraries/UI/Page/Page.php';

/**
 *
 * @author Joel Villasuso for VailHex
 *
 */
class SecurePage extends Page {
	
	/**
	 *
	 * @return string
	 */
	public function getMeta() {
		return "<title>TEST SECURE WEBSITE</title>";
	}
	/**
	 *
	 * @return string
	 */
	public function getHeader() {
		return "<h1> SECURE Header</h1>";
	}
	/**
	 *
	 * @return string
	 */
	public function getBody() {
		return "<h1> SECURE Footer</h1>";
	}
	/**
	 *
	 * @return string
	 */
	public function getFooter() {
		return "<h1> SECURE footer</h1>";
	}
	
	/**
	 *
	 * @return string
	 */
	public function getDoctype() {
		return "<!DOCTYPE html>";
	}
	/**
	 *
	 * @return string
	 */
	public function getHTMLProperties() {
		return "";
	}
	/**
	 *
	 * @return string
	 */
	public function getBodyProperties() {
		return "";
	}
	
	/**
	 *
	 * @return string
	 */
	final public function generate() {
		return parent::generate(true);
	}
}