<?php
set_include_path ( ".:/var/www/vailhex/" );
include_once 'phpLibraries/managers/dataSecurity.php';
include_once 'phpLibraries/UI/Page/Page.php';
 
/**
 *
 * @author Joel Villasuso for VailHex
 *
 */
class PublicPage extends Page {
	
	/**
	 * @return string
	 */
	public function getMeta() {
		return "<title>PARENT INDEX Page</title>";
	}
	/**
	 * @return string
	 */
	public function getHeader() {
		return "<h1>PARENT header</h1>";
	}
	/**
	 * @return string
	 */
	public function getBody() {
		return "<h1>PARENT Body</h1>";
	}
	/**
	 * @return string
	 */
	public function getFooter() {
		return "<h1>PARENT FOOTER</h1>";
	}
	
	/**
	 * @return string
	 */
	public function getDoctype() {
		return "<html>";
	}
	/**
	 * @return string
	 */
	public function getHTMLProperties() {
		return "";
	}
	/**
	 * @return string
	 */
	public function getBodyProperties() {
		return "";
	}
	
	/**
	 * @return string
	 */
	final public function generate(){
		return parent::generate(false);
	}

}