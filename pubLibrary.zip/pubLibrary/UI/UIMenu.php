<?php

set_include_path ( ".:/var/www/vailhex/" );


include_once 'phpLibraries/setup/MenuManager.php';
include_once 'phpLibraries/setup/MenuElement.php';


/**
 * Class that deals with the basic display of the Menu
 *
 * @author Joel Villasuso for VailHex
 *
 */
class UIMenu{

	/**
	 * Retrieves the menu index and returns it as a proper HTML menu element.
	 * Utilizes the idea of multidimensionality to create menu depth.
	 * Gets information directly from MenuManager.
	 * 
	 * @return string HTML representation
	 */
	public static function graphMenuUI(){
		$tree = MenuManager::retrieveIndex(true);
	
		$o = self::menuRepetition(1, ...$tree );
	
		return $o;
	}
	
	/**
	 * Generates a leveled menu system for an infinite number of levels.
	 * Utilizes recursion to generate an unlimited level of menu elements.
	 * Each menu has classes menu and dimN, where N is the depth level.
	 * 
	 * @param int $level
	 * @param Menu ...$tree
	 * @return string
	 */
	private static function menuRepetition( $level, Menu ...$tree ){
		$o = "<div id=\"MLvl".$level."\" class=\"MCont\">";
	
		foreach($tree as $i){
			$o .= "<div class=\"M".$level."\" >";
	
			if($i->children != null){
				$o .= self::menuRepetition($level+1, ...($i->children) );
			}
	
			$o .= "<p  onclick=\"link('".$i->getLink()."')\">".$i->getDisplayName()."</p>";
			$o .= "</div>";
		}
	
		$o .= "</div>";
		return $o;
	}
}
