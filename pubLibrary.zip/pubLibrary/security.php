<?php

	/**
	 * Clears input data thoughroughly. 
	 * 
	 * @param string $data
	 * @return string
	 * 
	 */
	function clear_input($data) { #Clear the input from the input 
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}
	
	/**
	 * Clears input data but allows html slashes. 
	 * Not as secure as clear_input.
	 * 
	 * @param string $data
	 * @return string
	 */
	function htmlBased_clear_input($data) { #Clear the input from the input
		$data = trim($data);
		$data = stripslashes($data);
		return $data;
	}
	

	
	
	/**
	 * Library of simple methods that facilitate certain actions throughout the code.
	 * 
	 * @author Joel Villasuso for VailHex
	 *
	 */
	class ease{
		
		/**
		 * Clears input data thoughroughly. 
		 * 
		 * @param string $data
		 * @return string
		 */
		function clear_input($data) { #Clear the input from the input
			$data = trim($data);
			$data = stripslashes($data);
			$data = htmlspecialchars($data);
			return $data;
		}
		
		/**
		 * Clears input data but allows html slashes. 
		 * Not as secure as clear_input.
		 * 
		 * @param unknown $data
		 * @return string
		 */
		function htmlBased_clear_input($data) { #Clear the input from the input
			$data = trim($data);
			$data = stripslashes($data);
			return $data;
		}
		
		/**
		 * Reformats an array to be printed as "Key:: Value"
		 * Uses $row to call a number of tabs before the string. Useful for recursion in multidimensional arrays.
		 * 
		 * ::WARNING:: RECURSION USED FOR MULTIDIMENSIONAL ARRAYS. 
		 * 
		 * @param $data multidimensional array
		 * @param $row number of tabs to increase by
		 * @return string
		 */
		public function keys_values_string($data, $row = "0"){ 
			$out = "";
			$tabs = "";
			
			for($i = $row; $i>0; $i-- ){
				$tabs .= " --";
			}
			$tabs .= "> ";
			
			foreach ($data as $key => $value) {
				if( !is_array($value) )
				    $out .= $tabs.$key.":: ".$value."<br/>";
				else {
					$out .= $tabs.$key.":: ARRAY<br/>".self::keys_values_string($value, $row+1);
				}
			}
			return $out;
		}
		
		
		/**
		 * Allows easy retrieval of $_GET parameters if they are set.<br/>
		 * The function returns an empty string otherwise.<br/>
		 * The parameter can be required or not, if required and missing, returns an empty string.
		 * 
		 * @param string $param
		 * @param boolean $required DEFAULT = FALSE
		 * @return string
		 */
		public static function getIsset($param, $required = FALSE) {
			if(isset($_GET[$param])){
				return $_GET[$param];
			}else{
				if ($required){
// 					TODO THROW ERROR "MISSING $PARAM PARAMETER IN GET FORM"
// 					echo "ERROR :: Parameter \"".clear_input($param)."\" not found through GET";
				}
				return "";
			}
		}
		
		/**
		 * Allows easy retrieval of $_POST parameters if they are set.<br/>
		 * The function returns an empty string otherwise.<br/>
		 * The parameter can be required or not, if required and missing, returns an empty string.
		 * 
		 * @param string $param POST variable name
		 * @param boolean $required DEFAULT = FALSE
		 * @return unknown|string
		 */
		public static function postIsset($param, $required = FALSE) {
			if(isset($_POST[$param])){
				return $_POST[$param];
			}else{
				if ($required){
// 					TODO THROW ERROR "MISSING $PARAM PARAMETER IN POST FORM"
// 					echo "ERROR :: Parameter \"".clear_input($param)."\" not found through POST";
				}
				return "";
			}
		}
		
		/**
		 * @param unknown $param
		 * @param string $required
		 * @return unknown|string
		 */
		public static function sessionIsset($param, $required = FALSE) {
			if(isset($_SESSION[$param])){
				return $_SESSION[$param];
			}else{
				if ($required){
					// 					TODO THROW ERROR "MISSING $PARAM PARAMETER IN POST FORM"
					// 					echo "ERROR :: Parameter \"".clear_input($param)."\" not found through POST";
				}
				return "";
			}
		}
// 		/**
// 		 * Allows easy retrieval of $_SESSION parameters if they are set.<br/>
// 		 * The function returns an empty string otherwise.
// 		 * 
// 		 * @param unknown $param
// 		 * @param string $required DEFAULT = FALSE
// 		 * @return unknown|string
// 		 */
// 		public static function sessionIsset($param, $required = FALSE){
// 			sessionMan::start_once();
// 			if(isset($_POST[$param])){
// 				return $_POST[$param];
// 			}else{
// 				if ($required){
// // 					TOD_O THROW ERROR "MISSING $PARAM PARAMETER IN SESSION"
// 				}
// 				return "";
// 			}
// 		}
		
		/**
		 * Echoes $arg preceded by a "<br>" statement, emulating C's println() statement
		 * 
		 * @param string $arg
		 */
		public static function println($arg){
			echo "<br>";
			self::print_r( $arg ); // input cleared inside ease::print_r
		}
		
		/**
		 * Uses echo to print $arg with the added security of clear_input() 
		 * 
		 * @param string $arg
		 */
		public static function print_r($arg){
			echo clear_input($arg) ;
		}
		
		
		
		/**
		 * Echoes an alert with a js alert message with a string error code. 
		 * 
		 * @param $string 
		 * @param $code => default '00-00'
		 */
		public static function printError($string, $code='00-00') {
			echo "
				<script type='text/javascript'>
				 alert('\tERROR".$code."\nDetails: ".clear_input($string)."');
				</script>";
		}
		
		
		/**
		 * Part of a Store/Call pair of functions that will store jsAlerts to call later. 
		 * Stores an alert message later printed through js function alert() .
		 * 
		 * Second part := ease::alertCall()
		 * 
		 * @param $string Alert message
		 */
		public static function alertStore($string) {
			$e = ' alert("'.$string.'")';
			if (!isset($GLOBALS['alertErrors']) ) {
				$GLOBALS['alertErrors'] = array();
			}else{
				$GLOBALS['alertErrors'][] = $e ;
			}
		}	
		
		/**
		 *  Part of a Store/Call pair of functions that will store jsAlerts to call later.
		 *  Prints the stored Alert messages.
		 *  
		 *  First part := ease::alertStore($string)
		 */
		public static function alertCall(){
			if(isset($GLOBALS['alertErrors'])){
				echo "<script type=\"text/javascript\">";
				foreach($GLOBALS['alertErrors'] as $e){
					echo $e.";";
				}
				echo '</script>';
			}else{
				echo "<script type=\"javascript\">alert(\"NO ERRORS TO ALERT OF\") </script>";
			}
		}
		
		/**
		 * Immediate call to a js alert() function
		 * 
		 * @param unknown $string
		 */
		public static function jsAlert($string){
			$r = "<script type=\"text/javascript\">".$string."<script type=\"javascript\">alert(\"NO ERRORS TO ALERT OF\") </script>";
		}
		
		/**
		 * Properly returns possible boolean input.
		 * 
		 * @param $param Boolean to be considered. Will also return "TRUE" if $param is a non-empty string or int. 
		 * @return string => "TRUE" || "FALSE"
		 */
		public static function bool($param) {
			return clear_input($param)?"TRUE":"FALSE";
		}
		
		
		/**
		 * First part of a Store/Call pair that prints the input previously stored
		 * Second part := ease::printCall()
		 * 
		 * Stores printing values inside an accessible array that will later on be accessed
		 * to print all that was stored. Can be called multiple times.
		 * 
		 * ::WARNING:: HTML BASIC ARGUMENT VERIFICATION :: STORAGE
		 * 
		 * @param unknown ...$param
		 */
		public static function printStore(...$param){
			if(!isset($GLOBALS['sketchDraw']) ){
				$GLOBALS['sketchDraw'] = array();
			}
			foreach( $param as $val){
				$GLOBALS['sketchDraw'][] = $val;
			}
		}
		
		/**
		 * Second part of a Store/Call pair that prints the input previously stored.
		 * First part := ease::printStore(...$arg)
		 * 
		 * Call for all stored values inside an accessible array that was previously filled with
		 * printable arguments.
		 * 
		 * ::WARNING:: HTML BASIC ARGUMENT VERIFICATION :: ECHO
		 * 
		 * @return  int -> number of values printed; NULL -> on unset
		 */
		public static function printCall(){
			if( isset($GLOBALS['sketchDraw']) ){
				foreach($GLOBALS['sketchDraw'] as $val){
					if( is_object($val) ){
						if( get_class($val) == "printStatement"){
							echo $val;	
						}
					}
					else{ 
						echo htmlBased_clear_input($val);
					}
				}
				return sizeof($GLOBALS['sketchDraw']);
			}else{
				return null;
			}
		}
		
		/**
		 * Stores a series of strings under a targetId to be retrieved later on
		 * 
		 * @param unknown $targetId
		 * @param unknown ...$stmt
		 */
		public static function targetPrintStore($targetId, ...$stmt ){
			$targetId = clear_input($targetId);
			
			if(!isset($GLOBALS['targetedPrint']) ){
				$GLOBALS['targetedPrint'] = array();
				$GLOBALS['targetedPrint'][$targetId] = array();
			}elseif (!isset($GLOBALS['targetedPrint'][$targetId] ) ){
				$GLOBALS['targetedPrint'][$targetId] = array();
			}
			foreach( $stmt as $val){
				$GLOBALS['targetedPrint'][$targetId][] = $val;
			}
		}
		
		
		
		/**
		 * Retrieves and echoes a series of stored strings under a targetId
		 * 
		 * @param unknown $targetId
		 * @return NULL
		 */
		public static function targetPrintedCall($targetId) {
			$targetId = clear_input($targetId);
			if( isset($GLOBALS['targetedPrint'][$targetId]) ){
				foreach($GLOBALS['targetedPrint'][$targetId] as $val){
					if( get_class($val) == "printStatement"){
						echo $val;
					}else{ 
						echo htmlBased_clear_input($val);
					}
				}
				return sizeof($GLOBALS['targetedPrint']);
			}else{
				return null;
			}
		}
		
	}
	
	/**
	 * Stores data to be printed.
	 * Allows a new line "</br>" before and/or after the statement.
	 *
	 * @author Joel Villasuso for VailHex
	 *
	 */
	class printStatement{
		
		private $statement;
		private $nlBefore;
		private $nlAfter;
		
		public function __construct($statement = "", $nlBefore= false, $nlAfter = false){
			$this->statement = htmlBased_clear_input($statement);
			$this->nlBefore = $nlBefore;
			$this->nlAfter = $nlAfter;
		}
		
		public function __toString() {
			return ($this->nlBefore?"<br>":"").$this->statement.($this->nlAfter?"<br>":"");
		}
		
	}
	
	/**
	 * Checks for certain patterns in the given string.
	 * 
	 * @author Joel Villasuso for VailHex
	 *
	 */
	class inputCheck{
		const upper = "[a-z]+";
		const lower = "[A-Z]+";
		const num = "[0-9]+";
		const pass = "^[-!%^&*()_+|~={}\[\]:;'<>?,. a-zA-Z0-9]{10,16}$" ;
		const usr = "^[-!%^&*()_+|~={}\[\]:;'<>?,. a-zA-Z0-9]{6,}$";
		const email = "^[a-zA-Z0-9]+@[a-zA-Z0-9]+.[a-zA-Z0-9]{2,4}$";
		const phone = "^[ 0-9.\-]*$";
		
		public static function passwordValidate($pass, $format = null) {
			$r = inputCheck::password($pass);
			$flag = false;
			foreach ($r as $e){
				if($e != 1){
					$flag = true;
					break;
				}
			}
			return !$flag; //True when there is no problem (flag == false), false otherwise
		}
		public static function userValidate($usr, $format = null) {
			$r = inputCheck::user($usr);
			$flag = false;
			foreach ($r as $e){
				if($e != 1){
					$flag = true;
					break;
				}
			}
			return !$flag; //True when there is no problem (flag == false), false otherwise
		}
		public static function emailValidate($email, $format = null) {
			$r = inputCheck::email($email);
			$flag = false;
			foreach ($r as $e){
				if($e != 1){
					$flag = true;
					break;
				}
			}
			return !$flag; //True when there is no problem (flag == false), false otherwise
		}
		public static function phoneValidate($phone, $format = null) {
			$r = inputCheck::phone($phone);
			$flag = false;
			foreach ($r as $e){
				if($e != 1){
					$flag = true;
					break;
				}
			}
			return !$flag; //True when there is no problem (flag == false), false otherwise
		}
		
		
		public static function password($password, $format = array( inputCheck::upper, inputCheck::lower, inputCheck::num, inputCheck::pass) ) {
			return inputCheck::format($password, $format);
		}
		public static function user($usr, $format = array(inputCheck::usr) ) {
			return inputCheck::format($password, $format);
		}
		public static function email($usr, $format = array(inputCheck::email) ) {
			return inputCheck::format($password, $format);
		}
		public static function phone($usr, $format = array(inputCheck::phone) ) {
			return inputCheck::format($password, $format);
		}
		
		
		public static function format($string, $format) {
			session_start();
			$error = array();
			$i = 0;
			foreach ($format as $f ){
				$error[$i] = preg_match($f, $password);
				$i += 1;
			}
			return $error;
		}
		
	}
	
	
?>