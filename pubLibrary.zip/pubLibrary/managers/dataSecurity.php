<?php

set_include_path(".:/var/www/vailhex/");

include_once 'phpLibraries/managers/SqlParser.php';

/**
 * 
 * Allows for secure session data storage and verification.
 * Direct access to SqlParser to obtain data from the pertinent database(s).
 * 
 * Allows for storage of session information in the SESSION variable.
 * 
 * @author Joel Villasuso for VailHex
 * 
 */
class DataSecurity {

	// TODO set time-out feature
	// TODO set login cool-down timing feature (IP based) 
	// TODO set log-out feature
	
	const storage = 'dataSecurity';
	const timeOut = 3000;
	
	private $username;
	private $log_ip;
	private $time;
	private $verified;
	
	function __construct($username, $pass) {
		$this->username = $username;
		$this->log_ip = $_SERVER['REMOTE_ADDR'];
		$this->time = time();
		$this->verified = true; //allows user retrieval during checkCredentials
		self::checkCredentials($pass);  // Stores itself in session once done.
	}
	
	/**
	 * Gets the active username only if the user is verified.
	 * 
	 * @return string | false
	 */
	function get_username() {
		return ($this->verified)?$this->username:false;
	}
	
	/**
	 * Returns the stored username regardless of verification. 
	 * Empty string returned if no username stored.
	 * 
	 * @return string
	 */
	function get_username_insecurely() {
		return ($this->username != null)?$this->username:"";
	}
	
	/**
	 * True if signed out, False if not logged in originally.
	 * Logout occurs without data check.
	 * Output only tells if there was a login registered or not.</br>
	 * <b>Logout is always successful.</b>
	 * 
	 * @return boolean
	 */
	static function logout(){
		$ds = self::get_from_session();
		$i = $ds->verified;
		$ds->verified = false;
		$ds->store_in_session();
		return $i;
	}
	
	/**
	 * Looks at $_POST for login data. Checks Post indexes:
	 * >'login_username'
	 * >'login_password'
	 * 
	 * @return boolean|NULL
	 */
	static function login(){ 
		$usrCheck = isset($_POST['login_username']);
		$pswCheck = isset($_POST['login_password']);
			
		if( $usrCheck & $pswCheck ){
			$usr = clear_input($_POST['login_username']);
			$psw = clear_input($_POST['login_password']);
			
			new DataSecurity($usr, $psw);
			$ds = DataSecurity::get_from_session();
// 			echo $ds->isVerified()? "True" : "False";
			return $ds->isVerified();
		}elseif( !$usrCheck && $pswCheck){    // PROBABLY NOT GOING TO BE USED, beautiful looking if used
			// 			echo "PASS ONLY";
			$psw = clear_input($_POST['login_password']);
			$ds = DataSecurity::get_from_session();
			$ds->checkCredentials($psw);
			return $ds->isVerified();
		}else{ // ( !$usrCheck && !$pswCheck )
			// 			echo "NO LOGIN DATA";
			return null;
		}
	}
	
	/**
	 * Looks at $_POST for registration data. Checks Post indexes:
	 * >'registration_username'
	 * >'registration_password1'
	 * >'registration_password2'
	 * >'registration_email'
	 * 
	 * @return boolean
	 */
	static function register(){
		$usr = isset($_POST['registration_username']);
		$psw = isset($_POST['registration_password1']);
		$psw2 = isset($_POST['registration_password2']);
			
		if($usr && $psw && $psw2){
			if(SqlBasis::registerUser()){
				$ds = new DataSecurity(ease::postIsset("registration_username"),
						ease::postIsset("registration_password1"));
			}
			return DataSecurity::get_from_session()->isVerified();
		}
	}
	
	/**
	 * Checks for a given password and the stored username ( in __construct)
	 * 
	 * @param string $pass unhashed
	 * @return boolean
	 */
	function checkCredentials($pass){
		//TODO: remove first store_in_session from here and test
		self::store_in_session();
		if (SqlBasis::checkUser($pass) ) {
			$this->verified = true;
		}else{
			$this->verified = false;
		}
		self::store_in_session();
		return $this->verified;
	}

	/**
	 * Verifies if the IP is the same as the one in storage
	 * 
	 * @return boolean
	 */
	function verifyIp(){
		if ( $_SERVER['REMOTE_ADDR'] == $this->log_ip ){
// 			$this->verified = true;
// 			self::store_in_session();
			return true;
		}
		return false;
	}
	
	/**
	 * Checks if the session is verified
	 * 
	 * @return boolean
	 */
	function isVerified(){
		return $this->verified;
	}
	
	/**
	 * Stores in session
	 */
	function store_in_session() {
		self::sessionStartOnce();
		$_SESSION[self::storage] = $this;
	}
	
	/**
	 * @return DataSecurity
	 */
	static function get_from_session(){
		self::sessionStartOnce();
		if ( $s = $_SESSION[self::storage] )
			if (get_class($s) == 'DataSecurity') {
				return $s;
			}
		return new DataSecurity('guest', 'guest');
	}
	
	/**
	 * Starts session
	 */
	static function sessionStartOnce(){
		if (session_status() == PHP_SESSION_NONE ) {
			session_start();
		}
	}
	
}


