<?php
include_once 'phpLibraries/security.php';

/**
 * Stores named Error objects on SESSION that can each be called back by the given name.
 * When an error is recalled, it is errased from the stack unless told otherwise. This is done to conserve memory.
 *
 * @author Joel Villasuso for VailHex
 * @version v2.3
 */
class errorManager {
	/**
	 * Storage point of all errors in SESSION
	 * @var string
	 */
	private static $global = "SessionErrorSystem";
	/**
	 * Stores the value of the error in the stack. Objects stored by the erros' native code by default.
	 * Specify $storageCode if the error should be stored with a different name.
	 * 
	 * @param Error $error
	 * @param string $storageCode = $error->message
	 */
	public static function setError(Error $error, $storageCode = false) {
		$code = (! $storageCode) ? $error->code : $storageCode;
		if (session_status () == PHP_SESSION_NONE) {
			session_start ();
		}
		if (! isset ( $_SESSION [self::$global] [$code] )) {
			$_SESSION [self::$global] [$code] = $error;
		}
	}
	/**
	 * Recalls an error by the given name.
	 * The value (if found) will be deleted by default.
	 * Giving an argument of false to $errase will bypass this.
	 *
	 * @param String $code        	
	 * @param Boolean $errase
	 *        	= true
	 * @return Error
	 */
	public static function getError($code, $errase = true) {
		if (session_status () == PHP_SESSION_NONE) {
			session_start ();
		}
		if (isset ( $_SESSION [self::$global] [$code] )) {
			$s = $_SESSION [self::$global] [$code];
			if ($errase) {
				unset ( $_SESSION [self::$global] [$code] );
			}
			return $s;
		}
		return new Error("","");
	}
	/**
	 * Recalls all errors from the session.
	 * All values will be errased afterwards.
	 * Giving an argument of false to $errase will bypass this.
	 *
	 * @param Boolean $errase
	 *        	= true
	 * @return Error[]
	 */
	public static function listAllErrors($errase = true) {
		if (session_status () == PHP_SESSION_NONE) {
			session_start ();
		}
		if (isset ( $_SESSION [self::$global] )) {
			$s = $_SESSION [self::$global];
			if ($errase) {
				unset ( $_SESSION [self::$global] );
			}
			return $s;
		}
		return array ();
	}
}

/**
 *
 * @author Joel Villasuso
 */
class Error {
	public $msg;
	public $code;
	function __construct($msg, $code) {
		$this->msg = clear_input ( $msg );
		$this->code = clear_input ( $code );
	}
	/**
	 * Generates an html form of the error.
	 * Seen as a parragraph element of class ErrorMessage
	 *
	 * @return string
	 */
	public function genHTML() {
		if ($this->msg != null) {
			return '<p class="ErrorMessage" code="' . $this->code . '" >' . $this->msg . '</p>';
		} else {
			return "";
		}
	}
	/**
	 * Checks whether it is an empty error.
	 *
	 * @return boolean
	 */
	public function isEmpty() {
		if ($this->msg == null && $this->code == null) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * Generates a string containing the error message.
	 *
	 * @return string
	 */
	public function genString() {
		if ($this->msg != null) {
			return ' ERROR >> CODE :: ' . $this->code . "  MESSAGE :: " . $this->msg;
		}
	}
	public function genInputError() {
		return new inputError ( $this->msg, $this->code );
	}
	public function __toString() {
		return $this->genHTML ();
	}
}