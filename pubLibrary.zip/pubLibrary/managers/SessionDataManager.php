<?php


set_include_path ( ".:/var/www/vailhex/" );

include_once 'phpLibraries/security.php';

/**
 *
 * @author Joel Villasuso for VailHex
 *
 */
class SessionDataManager {
	
	/**
	 * @param unknown $arg
	 */
	static public function addElement($arg){
		self::start_once();
		$o = ease::sessionIsset(self::location() );
		if( isset( $_SESSION[self::location()] ) && is_array($o)){
			foreach ($o as $k => $v){
				if($arg == $v){
					unset($o[$k]);
				}
			}
			$o[] = $arg;
			$_SESSION[self::location()] = $o;
		}else{
			$_SESSION[self::location()] = array( $arg );
			print_r($_SESSION[self::location()]);
		}
	}
	
	/**
	 * @param unknown $arg
	 * @return boolean
	 */
	static public function removeElement($arg){
		self::start_once();
		$o = ease::sessionIsset(self::location());
		if(isset( $_SESSION[self::location()] ) && is_array($o)){
			foreach ($o as $k => $v){
				if($arg == $v){
					unset($o[$k]);
				}
			}
			$_SESSION[self::location()] = $o;
			return true;
		}else{
			return false;
		}
		return false;
	}
	
	/**
	 * @return string|boolean
	 */
	static public function listElements(){
		self::start_once();
		$o = ease::sessionIsset(self::location());
		if(isset( $_SESSION[self::location()] ) && is_array($o)){
			return $o;
		}else{
			return false;
		}
	}
	
	
	static public function location(){
		return get_called_class();
	}
	
	//Starts the Session if not already
	static public function start_once(){
		if(!self::sessionCheckAlive() ) {
			session_start();
		}
		return session_status();
	}

	//Checks if the Session has already been started
	static public function sessionCheckAlive(){
		if (session_status() == PHP_SESSION_ACTIVE) {
			return true;
		}else {
			return false;
		}
	}
}

