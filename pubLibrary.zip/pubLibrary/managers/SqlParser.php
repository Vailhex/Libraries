<?php
set_include_path ( ".:/var/www/vailhex/" );

include_once 'phpLibraries/managers/dataSecurity.php';

/**
 * General class for SqlData management.
 * 
 * Based on a hardwired PDO initialization (for security) and a queryRoulette method to generate 
 * queries from fixed statements.
 * 
 * SqlGetter and SqlSetter are both children classes of this one
 * 
 * @author Joel Villasuso for VailHex
 * 
 */
class SqlBasis{
	/**
	 * Generates a PDO handle for querring. If any errors present, returns false and echoes "Error: Sql DataBase issue".
	 *
	 * @return PDO | false
	 */
	protected static function genPDOHandle() {
		try {
			$handle = new PDO ( 'mysql:host=127.0.0.1;dbname=villasArt',
					'villasArt', 'managerPassword', array( PDO::ATTR_PERSISTENT => false) );
			$handle->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
			return $handle;
		}
		catch ( PDOException $e ) {
			return false;
		}
	}
	
	/**
	 * Gets the username stored in session. 
	 * FIXME Function should be in DataSecurity.
	 * 
	 * @return string | false
	 */
	static function getSessionUsername() {
		$sq = DataSecurity::get_from_session ();
		if ($sq != null && get_class ( $sq ) == "DataSecurity")
			return $sq->get_username ();
			return false;
	}

	/**
	 * Allows the registration of new users.
	 * Returs boolean to show success.
	 * 
	 * @return true | false
	 */
	static function registerUser(){
		$usr = ease::postIsset('registration_username');
		
		$psw = ease::postIsset('registration_password1');
		$psw2 = ease::postIsset('registration_password2');
	
		if($psw == $psw2){
			$psw=password_hash($psw2, PASSWORD_BCRYPT);
		}else{
			return false;
		}
		
		$load =  new QueryLoader("insert into profile (username,hash) values (:usr,:psw)");
		$load->bp(new BindingPair("usr", $usr ));
		$load->bp(new BindingPair("psw", $psw ));
		$load->execute();

		return true;
	}
	
	/**
	 * Compared the password to the hashed password for the user in $_SESSION
	 * 
	 * @param string $pass
	 * @return true | false | NULL
	 */
	static function checkUser($pass){
		$load =  new QueryLoader("select hash from profile where username = :username ");
		$load->bp(new BindingPair("username", self::getSessionUsername() ));
		$i = $load->execute();
		
		if ($i != null) {
			$v = password_verify($pass, $i['hash']);
			if ($v) {
				self::updateHash($pass);
			}
			return $v;
		}
		
		return null;
	}

	/**
	 * Update the password hash.
	 * Data stream from stored SESSION.
	 * Private to prevent pass-override before verification in <i>check_user($pass)</i> .
	 *
	 * @param string $pass
	 */
	private static function updateHash($pass){

		$load =  new QueryLoader("update profile set hash = :pass where username = :username");
		
		if ($handle = SqlBasis::genPDOHandle ()) {
			if ($prep = $handle->prepare ( $queryString )) {
				if ($usr = DataSecurity::get_from_session() ) {
					$load->bp(new BindingPair("username", $usr->get_username() ));
					$load->bp(new BindingPair("pass", password_hash($pass, PASSWORD_BCRYPT)  ));
					$load->executeSilent();
				}
			}
		}
	}
}

/**
 * Allows simple queries to be easily formed to a predefined database.
 * Requires the usage of <i>BindingPair</i> if query data is to be given dynamically. 
 * 
 * @author Joel Villasuso
 *
 */
class QueryLoader extends SqlBasis{
	
	public $params;
	public $query;
	
	function __construct($query) {
		$this->query = $query;
		$this->params = array();
		return $this;
	}
	
	/**
	 * Adds a list of BindingPairs to the query.
	 * 
	 * @param BindingPair ...$params
	 */
	function bp( BindingPair... $params) {
		foreach ($params as $p)
			$this->params[] = $p;
	}
	
	/**
	 * Executes the query. Allows output.
	 * 
	 * @param string $all
	 * @return true | false | array
	 */
	function execute($all = FALSE) {
		return $this->executeFull($all);
	}
	/**
	 * Executes the query. Does not allow output.
	 * 
	 * @return true | false 
	 */
	function executeSilent(){
		return $this->executeFull(false, false);
	}
	
	/**
	 * Inner method to execute the query.
	 * 
	 * @param string $all take all elements or only the first.
	 * @param string $output allow output or not.
	 * @return array | true | false 
	 */
	private function executeFull($all = FALSE, $output = true) {
		try {
		$queryString = $this->query;
		if ($handle = self::genPDOHandle ()) {
			if ($prep = $handle->prepare ( $queryString )) {
				if(is_array($this->params) && sizeof($this->params) > 0 )
				foreach ($this->params as $p){
					if (get_class($p) == "BindingPair") 
						$prep->bindParam ( $p->key, $p->val );
				}
				$prep->execute ();
				
				if($output){ //makes sure there is viable output
					if ($all) //chooses one or the other
						$arr = $prep->fetchAll ( PDO::FETCH_ASSOC );
					else  
						$arr = $prep->fetch ( PDO::FETCH_ASSOC );
					return $arr;
				}
			}
		}
		} catch (Exception $e) {
			echo "ERROR::".print_r($e,true);  // XXX THROW ERRORS PROPERLY
		}
		return false;
	}
}

/**
 * Allows easy storage of data pairs. Intended for QueryLoader.
 * Stored a key and a value. Key stored with a prepended ':' character.
 * Inner variables public for ease of retrieval. No getter/setter 
 * required due to user only of developer and no outside input.
 * 
 * XXX Could use the help of further input filtering.
 * 
 * @author Joel Villasuso
 */
class BindingPair{
	public $val;
	public $key;
	
	function __construct( $key, $val){
		$this->key = ":".$key;
		$this->val = $val;
	}
}

