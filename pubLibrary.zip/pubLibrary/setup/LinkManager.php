<?php

set_include_path ( ".:/var/www/vailhex/" );

include_once 'phpLibraries/setup/LinkElement.php';


/**
 *
 * @author Joel Villasuso for VailHex
 *
 */
class LinkManager {


	static private $filDir = "setup/resources";
	/* IDEA encrypt data before storage. 
	 *  -> data can be encrypted before storage and unencrypted given a key.
	 *  -> security level depends on encryption capacity and key storage and handling.
	 */ 
	
	// TODO addToIndex: aggregates a Link to the Index.
	// TODO removeFromIndex: removes an array of Link from the index.
	// TODO Create a config file where to get the fileDir from.
	
	/**
	 * Stores a list of Links into the Index.
	 * The Index is a file, and the data is stored through serialization.
	 * The file address in hardwired into the class.
	 * 
	 * @param Link ...$links
	 */
	static public function storeIndex( Link ...$links ) {
		$file = fopen( LinkManager::$filDir, "w+");
		fwrite( $file, serialize($links) );
		fclose( $file );
	}

	/**
	 * Retrieves the Link Index.
	 * Files are loaded from the file directory (filDir) 
	 * 
	 * @return Link[]
	 */
	static public function retrieveIndex(){
		$file = fopen( LinkManager::$filDir, "r");
		$tree = fread( $file , filesize(LinkManager::$filDir) );
		fclose($file);
		return unserialize($tree);
	}

	
	/**
	 * Finds the addressed resource between the Links.
	 * Returns false if not found
	 * 
	 * @param string $address
	 * @return Link|false
	 */
	static public function find( $address ) {
		if ( $address == null ) return false;

		$tree = self::retrieveIndex();
// 		print_r($tree);
// 		echo '>>>retrieving '.$address."\n";
		foreach($tree as $elem){
// 			echo "looking into ".$elem->address."\n";
			$i = Link::findAddress($address, $elem,  true);
			if($i != null){
// 				print "\n\n\t------->found ".$i->address."\n";
				return $i;
			}
// 			print '------->impossible '.$address."\n";
		}
		return false;
	}
	
// 	TODO register a find by name once that is enabled in Link

}