<?php

set_include_path ( ".:/var/www/vailhex/" );

include_once 'phpLibraries/setup/MenuElement.php';

/* IDEA possible MenuManager & LinkManager configuration file directives.
 *		> changing default file directory
 *		> enable/disable encryption
 */

# include_once all pages
foreach (glob("phpLayout/pages/*.php") as $filename)
{
	include_once $filename;
}

/**
 *
 * @author Joel Villasuso for VailHex
 *
 */
class MenuManager {
	
	static private $filDir = "setup/menu";

	/* IDEA consolidate this class MenuManager with LinkManager */
	
	/* TODO extend capacity of MenuManager class:
	 * 		-> allow adding and removing elements.
	 * 		-> allow more requirement filtering
	 */
	
	// TODO addToIndex: aggregates a Menu to the Index.
	// TODO removeFromIndex: removes an array of Menu from the index.
	
	/**
	 * Serializes and writes the Menu tree. It must be given as a list of elements, not as an array
	 * 
	 * @param Menu ...$menus
	 */
	static public function storeIndex( Menu ...$menus ) {
		$file = fopen(MenuManager::$filDir, "w+");
		fwrite( $file, serialize($menus) );
		fclose( $file );
	} 
	
	/**
	 * Serializes and writes the Menu tree. It must be given as a list of elements, not as an array.
	 * Stores it in a custom file.
	 * 
	 * <b>NOTE:: No error handling</b>
	 *
	 * @param Menu ...$menus
	 */
	static public function storeCustomIndex( $fileDir, Menu ...$menus ) {
		
		//FIXME secure access required, currently insecure.
		
		$file = fopen( $fileDir, "w+");
		fwrite( $file, serialize($menus) );
		fclose( $file );
	}
	/**
	 * Retrieves the menu index from file.
	 * Storage is based on serialization of an array of Menu objects.
	 * 
	 * @return Menu[]
	 */
	static public function retrieveIndex( $reqVisibility = FALSE ){
		$file = fopen(MenuManager::$filDir, "r");
		$tree = fread($file , filesize(MenuManager::$filDir) );
		
// 		print_r(unserialize($tree));
		
		$tree = self::requirements($reqVisibility, ...unserialize($tree)); // checks requirements
		
		fclose($file);
		return $tree;
	}
	
	/**
	 * Retrieves the menu index from file.
	 * Storage is based on serialization of an array of Menu objects.
	 * retrieves from a custom, predefined file.
	 * 
	 * <b>NOTE:: No error handling</b>
	 * 
	 * @return Menu[]
	 */
	static public function retrieveCustomIndex( $fileDir, $reqVisibility = FALSE ){

		//FIXME secure access required, currently insecure.
		
		$file = fopen($fileDir, "r");
		$tree = fread($file , filesize(MenuManager::$filDir) );
		
// 		print_r(unserialize($tree));
		
		$tree = self::requirements($reqVisibility, ...unserialize($tree)); // checks requirements
		
		fclose($file);
		return $tree;
	}
	
	static public function requirements( $visibility, Menu ...$tree ) {

		$o = array();
		if($visibility){
			foreach($tree as $e){
				if($e->visibility){
					array_push($o, $e);
				}
			}
		}else{
			$o = $tree;
		}
		return $o;
	}
	
	/**
	 * Find a named menu in the stored menu index.
	 * Returns a Page object that is stored in the found Menu, or the page NotFound as an alternative.
	 * 
	 * @param string $name
	 * @return Page|NotFound
	 */
	static public function find( $name) {
		if ($name == null ) $name = 'index';
		
		$tree = self::retrieveIndex();
		foreach($tree as $elem){
			$i = Menu::find($name, $elem,  true);
			if($i != null){
				return $i->object;
			}
		}
		return (new NotFound());
	}
	
// 	PENDING create a find by class as well as by name -> could be through more arguments.

}