<?php

set_include_path ( ".:/var/www/vailhex/" );

include_once 'phpLibraries/UI/Page/Page.php';
include_once 'phpLibraries/UI/Page/PublicPage.php';
include_once 'phpLibraries/UI/Page/SecurePage.php';

/* IDEA possible Menu configure file directives 
 *  	> default Page visibility
 *  	> anchor design (class,id, and naming)
 * 		> recursiveness default
 *  	> link format (getLink)
 *  	> query of Name or Class only
 *  	> allow hierarchy
 * */


/**
 * Menu stores an Page object and a given name.
 * This allows for storage and retrieval of the page through indexing of the Menu item.
 * The Menu hierarchy can be done through the storage of children Menu elements.
 * These children are circled through when searching for a specific menu.
 * 
 * @author Joel Villasuso for VailHex
 */
Class Menu {
	
	public $name;
	public $object;
	public $children;
	public $visibility = true;
	
	function __construct($name , Page $object = null, $visible , Menu ...$children ){
		$this->name = $name;
		$this->object = ($object == null)? (new PublicPage()) : $object; // new PublicPage or defined Object
		$this->visibility =  $visible ;
// 		if (sizeof( $children) > 1) {
// 			$this->children = $children;
// 		}elseif(){
			
// 		}
		$this->children = (sizeof( $children) > 1)? $children : ((sizeof( $children) == 1)? array($children) : null) ;
		// changed the storage of $children to force an array to be stored even if only one child.
	}
	
	/**
	 * Gets the address for the page.
	 * Simply, gets the name
	 * 
	 * @return string name
	 */
	function getLink(){
		return $this->getDisplayName() . $this->object->getLink();
	}
	
	function getDisplayName() {
		return $this->name;
	}
	
	/**
	 * Get the HTML anchor for the Menu.
	 * Does not take menu hierarchy into consideration
	 * 
	 * @return string
	 */
	function getAnchor(){
		return "<a href='".$this->getLink()."'>".$this->name."</a>";
	}
	
	/**
	 * Returns the children of the Menu.
	 * Can return a Menu array or null if empty.
	 * 
	 * @return Menu[] | null 
	 */
	function getChildren(){
		return $this->children;
	}
	
	/**
	 * Gets the number of children in Menu.
	 * 
	 * @return integer size
	 */
	function familySize(){
		return sizeof($this->children);
	}
	
	/**
	 * Simple check regarding visibility of the Menu object.
	 * Returns the Menu by default. 
	 * 
	 * @param Menu $i
	 * @param boolean $reqVisible
	 * @return Menu|NULL
	 */
	private static function visibilityReq(Menu $i, $reqVisible = FALSE){
	/* if( not requiredVisible) -> 	return $i
	 * elseif( $i is visible ) 	-> 	return $i
	 * else 					-> 	return null
	 * 
	 * return visibilityReq($i,$reqVisible);
	 */
		return (!$reqVisible)? $i : ($i->visibility? $i : null);
	}
	
	
	/**
	 * Finds the Menu with name $name.</br>
	 * Doesn't check $name, hence for private use only.</br>
	 * </br>
	 * Uses recursion to check for itself and each child.</br>
	 * 
	 * @param Menu $menu
	 * @param String $name
	 * @param Boolean $recursion = true
	 * @return Menu|NULL
	 */
	private static function queryName(Menu $menu, $name, $recursion = true, $reqVisible = FALSE){
		
// 		echo "    NameQuery: ".$menu->name."\n";
		if (strtolower($menu->name) == $name)
			return $menu;
		
		if ($menu->children != null && $recursion )
			foreach ($menu->children as $child){
				$i = self::queryName($child, $name);
				if($i != null){
					return $i;//visibilityReq($i,$reqVisible);
				}
			}
// 		print "\tmenuQuery is empty\n";
		return null;
	}
	
	/**
	 * Finds the Page with class name $name.</br>
	 * Doesn't check $name, hence for private use only.</br>
	 * </br>
	 * Uses recursion to check for itself and each child.</br>
	 * 
	 * @param Menu $menu
	 * @param String $name
	 * @param Boolean $recursion = true
	 * @return Menu|NULL
	 */
	private static function queryObject(Menu $menu, $name, $recursion = true, $reqVisible = FALSE){
// 		print "    ObjectQuery: ".$menu->name."\n";

		if (strtolower($menu->object->getName()) == $name)
			return $menu;
		
		if ($menu->children != null && $recursion )
			foreach ($menu->children as $child){
				$i = self::queryObject($child, $name);
				if ($i != null){
					return $i;// visibilityReq($i,$reqVisible);
				}
			}
// 		print "\tclassQuery is empty\n";
		return null;
	}
	
	/**
	 * Query the Menu given as class and/or menu name.  
	 * 
	 * @param String $name
	 * @param string $recursion
	 * @param string $MenuQuery
	 * @param string $ClassQuery
	 * @return Menu|NULL
	 */
	private static function queryMenu( Menu $elem, $name, $recursion=false, $MenuQuery = true, $ClassQuery = false, $reqVisible = FALSE ) {
		if ($name != null) {
			$name = strtolower($name);
			if ($MenuQuery){
				$m = self::queryName($elem, $name, $recursion, $reqVisible);
				if ($m != null){
// 					print "\tmenuQuery FOUND\n";
					return $m;
				}else{
				}
			}
			if ($ClassQuery){
				$c = self::queryObject($elem, $name, $recursion, $reqVisible);
				if ($c != null){
// 					print "\tclassQuery FOUND\n";
					return $c;
				}else{
				}
			}
		}
		return null;
	}
	
	
	/**
	 * Finds a child element by Menu name
	 * 
	 * @param String $name
	 * @param string $recursive
	 * @return Menu|NULL
	 */
	public static function findMenu( $name, Menu $menu = null , $recursive = false, $reqVisibleble = FALSE) {
		if ($menu == null) {
			$menu = $this;
		}
		return self::queryMenu($menu, $name, $recursive, true, falsereqVisibleisible);
	}
	
	/**
	 * Finds a child element by Page name
	 * 
	 * @param String $name
	 * @param string $recursive
	 * @return Menu|NULL
	 */
	public static function findClass( $name, Menu $menu = null , $recursive = false, $reqVisible = FALSE){
		if ($menu == null) {
			$menu = $this;
		}
		return self::queryMenu($menu, $name, $recursive, false, true, $reqVisible);
	}
	
	/**
	 * Finds a child element by Menu and Page name. Must match <b>only one</b>.
	 * 
	 * @param String $name
	 * @param string $recursive
	 * @return Menu|NULL
	 */
	public static function find( $name, Menu $menu = null , $recursive = false, $reqVisible = true){
		if ($menu == null) {
			$menu = $this;
		}
		return self::queryMenu($menu,$name, $recursive, true, true, $reqVisible);
	}
	
	
	
}