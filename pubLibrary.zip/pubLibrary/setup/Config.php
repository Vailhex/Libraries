<?php

set_include_path ( ".:/var/www/vailhex/" );


/**
 *
 * @author Joel Villasuso for VailHex
 *
 */
class Config {
	
	/* PENDING configuration-file directive recognition and output. 
	 * 		-> each class should have functions that are defined by the configuration.
	 * 		-> configuration could have a certain level of encryption.
	 */
	
}