<?php

set_include_path ( ".:/var/www/vailhex/" );

include_once 'phpLibraries/setup/LinkManager.php';


/**
 * A link element to a file resource.
 * References an element by type (header) and location (address).
 * 
 * Used in the storage and retrieval of resources.
 * 
 * @author Joel Villasuso for VailHex
 *
 */
Class Link{
	
	public $address;
	public $header;

	static public $image = 'image' ;
	static public $png = 'image/png' ;
	static public $jpeg = 'image/jpg' ;
	static public $jpg = 'image/jpg' ;
	static public $gif = 'image/gif' ;
	static public $bmp = 'image/bmp' ;
	static public $ico = 'image/x-icon' ;
	static public $svg = 'image/svg+xml' ;
	
	static public $text = 'text' ;
	static public $css = 'text/css' ;
	
	static public $js = 'application/javascript' ;
	
	function __construct($address, $header ){
		$this->address = ($address == null)? " " : $address;
		$this->header = $header;
	}
	
	/**
	 * Generates a header and file-stream from the $header and $address variables respectively.
	 * Data obtained directly from the Link.
	 */
	function get(){
		header('Content-type: ' . $this->header);
		readfile($this->address);
	}
	
	
	/**
	 * Query by name of Link.
	 * Returns the Link if it's name matches.
	 * 
	 * @param Link $link
	 * @param string $name
	 * @param string $recursion
	 * @return Link|NULL
	 */
	private static function queryName(Link $link, $name, $recursion = true){
		
// 		PENDING not implemented due to the lack of name in class Link
		if ($link->name == $name)
			return $link;
// 		if ($link->children != null && $recursion )
// 			foreach ($link->children as $child){
// 				$i = self::queryName($child, $name);
// 				if($i != null) return $i;
// 			}
		return null;
	}
	
	/**
	 * Query by address of Link.
	 * Returns the Link if it's name matches.
	 * 
	 * 
	 * @param Link $link
	 * @param unknown $address
	 * @param string $recursion
	 * @return Link|NULL
	 */
	private static function queryAddress(Link $link, $address, $recursion = true){
		if ($link->address == $address)
			return $link;
// 		if ($link->children != null && $recursion )
// 			foreach ($link->children as $child){
// 				$i = self::queryAddress($child, $name);
// 				if ($i != null) return $i;
// 			}
		return null;
	}
	
	/**
	 * Queries both recursively or linearly by Name and/or by Address depending on the parameters.
	 * 
	 * None used since Link is strictly linear in design and lacks name.
	 * Left in place due to the possibility of versioning and for consistency with MenuManager.
	 * 
	 * <b>NOTE:</b> Currently AddressQuery and NameQuery are non-consequential since there is only name queries allowed. 
	 * Left for future Usage
	 * 
	 * @param Link $elem
	 * @param string $call
	 * @param string $recursion
	 * @param string $NameQuery
	 * @param string $AddressQuery
	 * @return Link|NULL
	 */
	private static function query( Link $elem, $call, $recursion=false, $NameQuery = true, $AddressQuery = false ) {
		if ($call != null) {
// 			if ($NameQuery){
// 				$m = self::queryName($elem, $call, $recursion);
// 				if ($m != null){
// 					return $m;
// 				}
// 			}
// 			if ($AddressQuery){
				$c = self::queryAddress($elem, $call, $recursion);
				if ($c != null){
					return $c;
				}
// 			}
		}
		return null;
	}
	
	
	/**
	 * Finds if a Link can be called by $name.
	 * Checks whether the given Link is null before returning.
	 * 
	 * @param string $name
	 * @param Link $link
	 * @param string $recursive
	 * @return Link|NULL
	 */
	public static function findName( $name, Link $link = null , $recursive = false) {
		if ($link == null) {
			return null; // $link = $this; // Not static if $this called.
		}
		return self::query($link, $name, $recursive);
	}
	
	/**
	 * Finds if a Link can be called by $address.
	 * Checks whether the given Link is null before returning.
	 * 
	 * @param string $address
	 * @param Link $link
	 * @param string $recursive
	 * @return Link|NULL
	 */
	public static function findAddress( $address, Link $link = null , $recursive = false){
		if ($link == null) {
			$link = $this;
		}
		return self::query($link, $address, $recursive, false, true);
	}
	
	
	/**
	 * @param strng $name
	 * @param Link $link
	 * @param string $recursive
	 * @return Link|NULL
	 */
	public static function find( $name, Link $link = null , $recursive = false){
		if ($link == null) {
			$link = $this;
		}
		return self::query($link,$name, $recursive, true, true);
	}
	
	
	/**
	 * Receives the file address and indexes all files inside, excluding folders.
	 * Automatically includes the header based on file extension.
	 * 
	 * @param String $dir
	 * @return Link[] 
	 */
	public static function populate($dir){
// 	 	PENDING extract extension recognition into a separate function
		$i = 0;
		$dir .= "/*";
		$list = array();
		$temp = glob($dir.'.*');
		
		while( sizeof($temp) != 0 ){
			$temp = glob($dir.'.*');
			foreach ($temp as $filename){
				$ar = split("\.", $filename);
				$ar = $ar[sizeof($ar)-1];  //get the last element in $ar
				try{
					array_push($list, new Link ($filename, Link::$$ar)); // Link::$$ar goes to the variable depending on the value of $ar
				}catch(Exception $e){
					//do nothing
				}
			}
			$dir .= "/*";
		}
		return $list;
	}
	
}