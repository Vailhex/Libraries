<?php
set_include_path ( ".:/var/www/vailhex/" );

include_once 'phpLibraries/security.php';

/**
 * Generates OOP HTML Forms through formLine and it's classes.
 * Includes parameters before (extra) and after (tail) the form itself.  
 * 
 * @author Joel Villasuso for VailHex
 *
 */
class FormFactory {
	private $data;
	const header = 'header';
	const body = 'body';
	const urlParam = 'urlParam';
	const submit = 'submit';
	const extra = 'extra';
	const tail = 'tail';
	public function __construct() {
		$this->data = array (
				self::header => "",
				self::body => array (),
				self::submit => "",
				self::tail => "</form>" 
		);
		$this->setHeader ();
		$this->setSubmit ();
	}
	public static function gen($target = "", $form = "POST", $headerClass = "", formLine ...$field) {
		$r = new formGen ();
		
		$r->setHeader ( $target, $form, $headerClass );
		$r->addInput ( $field );
		// setSubmit() called in __construct()
		
		return $r;
	}
	public function setHeader($target = "", $isPost = true, $class = "", ...$urlParams) {
		$action = ($target = "") ? $_SERVER ['REQUEST_URI'] : $target; // if target is empty, target is self
		
		if ($urlParams != null) {
			$action .= '?';
			foreach ( $urlParams as $pair ) {
				if (get_class ( $pair ) == 'urlParam')
					$action .= $pair . "&";
			}
			rtrim ( $action, "&" ); // removes the very last '&' if any is present
		}
		
		$method = ($isPost) ? 'POST' : 'GET';
		$this->data [self::header] = '<form class="' . $class . '" action="' . $action . '" method="' . $method . '">';
		return $this;
	}
	public function setSubmit($text = "Submit", $class = "formSubmit") {
		$this->data [self::submit] = '<input class="' . $class . '" type="submit" value="' . $text . '" >';
		return $this;
	}
	public function addInput(formLine ...$field) {
		foreach ( $field as $item ) {
			if (is_subclass_of ( $item, 'formLine' )) {
				$this->data [self::body] [] = $item->gen ();
			}
		}
		return $this;
	}
	public function addExtra(formLine ...$field) {
		foreach ( $field as $item ) {
			if (is_subclass_of ( $item, 'formLine' )) {
				$this->data [self::extra] [] = $item->gen ();
			}
		}
		return $this;
	}
	public function __toString() {
		$out = "";
		$out .= $this->data [self::header];
		
		foreach ( $this->data [self::body] as $elem ) {
			$out .= $elem;
		}
		
		$out .= $this->data [self::submit];
		
		if (isset ( $this->data [self::extra] ))
			foreach ( $this->data [self::extra] as $elem ) {
				$out .= $elem;
			}
		
		if (isset ( $this->data [self::tail] ))
			$out .= $this->data [self::tail];
		
		return $out;
	}
}
class inputSubmit {
	public $className;
	public $value;
	public $type;
	function __construct($className, $value, $type = "POST") {
		$this->className = ease::clear_input ( $className );
		$this->value = ease::clear_input ( $value );
		$this->type = ease::clear_input ( $type );
	}
	function gen() {
		return '<input class="' . $this->className . '" type="submit" value="' . $this->value . '" >';
	}
	public function __toString() {
		return $this->gen ();
	}
}
class inputField implements formLine {
	public $req;
	public $type;
	public $name;
	public $pHold;
	public $val;
	function __construct($name = "input", $placeHolder = "input", $type = "text", $req = false, $val = "") {
		$this->name = ease::clear_input ( $name );
		$this->pHold = ease::clear_input ( $placeHolder );
		$this->type = ease::clear_input ( $type );
		$this->req = ease::clear_input ( $req );
		$this->val = ease::clear_input ( $val );
	}
	function gen() {
		$out = '<input class="login_form" type="' . $this->type . '" name="' . $this->name . '" placeholder="' . $this->pHold . '" value="' . $this->val . '" ';
		if ($this->req == true) {
			$out .= 'required>';
		} else {
			$out .= ">";
		}
		return $out;
	}
	public function __toString() {
		return $this->gen ();
	}
}
class inputSelect implements formLine {
	public $name;
	public $options = array ();
	public function __construct($nameArg) {
		$this->name = $nameArg;
		return $this;
	}
	public function addOption(inputSelectOption $optionArg) {
		$this->options [] = $optionArg;
		return $this;
	}
	public function gen() {
		$o = "<select name =\"" . $this->name . "\" >";
		foreach ( $this->options as $opt ) {
			$o .= $opt;
		}
		$o .= "</select>";
		return $o;
	}
	public function __toString() {
		return $this->gen ();
	}
}
class inputSelectOption {
	public $name;
	public $content;
	function __construct($nameArg, $contArg) {
		$this->name = $nameArg;
		$this->content = $contArg;
		return $this;
	}
	function gen() {
		$o = "<option value=\"" . $this->name . "\" >" . $this->content . "</option>";
		return $o;
	}
	public function __toString() {
		return $this->gen ();
	}
}
class inputError implements formLine {
	public $error;
	public $code;
	function __construct($error = "An error occured", $code = "00-00") {
		$this->error = ease::clear_input ( $error );
		$this->code = ease::clear_input ( $code );
	}
	public function gen() {
		if ($this->error != null) {
			return '<p class="login_error" code="' . $this->code . '" >' . $this->error . '</p>';
		}
	}
	public function __toString() {
		return $this->gen ();
	}
	public static function generateError($error, $code = "00-00") {
		if ($error != null) {
			return new inputError ( $error, $code );
		} else {
			return null;
		}
	}
}
class inputText implements formLine {
	public $className;
	public $content;
	public function __construct($classArg, $contArg) {
		$this->className = ease::clear_input ( $classArg );
		$this->content = ease::htmlBased_clear_input ( $contArg );
	}
	public function gen() {
		return "<p class=" . $this->className . ">" . $this->content . "</p>";
	}
	public function __toString() {
		return $this->gen ();
	}
}
class lineBreak implements formLine {
	function __construct() {
	}
	public function gen() {
		return "<hr/>";
	}
	public function __toString() {
		return $this->gen ();
	}
}
interface formLine {
}
class urlParam {
	public $key;
	public $val;
	function __construct($key, $val) {
		$this->key = ease::clear_input ( $key );
		$this->val = ease::clear_input ( $val );
	}
	public function gen() {
		return $this->key . "=" . $this->val;
	}
	public function __toString() {
		return $this->gen ();
	}
}

?>
